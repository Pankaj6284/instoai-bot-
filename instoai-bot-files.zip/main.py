
import cohere
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters

co = cohere.Client("YOUR_COHERE_API_KEY")

def start(update, context):
    update.message.reply_text("Welcome to InstoAI! Type anything to get started.")

def reply(update, context):
    response = co.generate(
        model='command-r',
        prompt=update.message.text,
        max_tokens=100
    )
    update.message.reply_text(response.generations[0].text.strip())

def main():
    updater = Updater("YOUR_TELEGRAM_BOT_TOKEN", use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, reply))
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
